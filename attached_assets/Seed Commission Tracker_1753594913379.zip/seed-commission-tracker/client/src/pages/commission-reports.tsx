import React from 'react';

export default function CommissionReports() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Commission Reports</h1>
      <p>Commission reports coming soon...</p>
    </div>
  );
}