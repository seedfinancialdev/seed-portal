import React from 'react';

export default function DealsManagement() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Deals Management</h1>
      <p>Deals management coming soon...</p>
    </div>
  );
}